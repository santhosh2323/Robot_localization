#!/usr/bin/env python3

import rospy
from nav_msgs.msg import Odometry
import matplotlib.pyplot as plt
from threading import Lock
import numpy as np
from tf.transformations import euler_from_quaternion

class Ground_Truth_Plotter:
    def __init__(self):
        self.x_values = []
        self.y_values = []
        self.yaw_values = []
        self.data_lock = Lock()
        # Initialize ROS node
        rospy.init_node("ground_truth_plotter", anonymous=True)
        rospy.Subscriber("/kitti/oxts/odom", Odometry, self.odom_callback)
        plt.ion()
        self.fig, self.ax = plt.subplots()
        self.ax.set_xlabel("X (meters)")
        self.ax.set_ylabel("Y (meters)")
        self.ax.set_title("Robot Trajectory with Orientation")
        self.ax.grid(True)
        self.run_plot_loop()

    def odom_callback(self, msg):
        """Callback function to process odometry data."""
        with self.data_lock:
            position = msg.pose.pose.position
            orientation = msg.pose.pose.orientation
            self.x_values.append(position.x)
            self.y_values.append(position.y)
            quaternion = (
                orientation.x,
                orientation.y,
                orientation.z,
                orientation.w,
            )
            _, _, yaw = euler_from_quaternion(quaternion)
            self.yaw_values.append(yaw)

    def update_plot(self):
        with self.data_lock:
            self.ax.clear()
            self.ax.plot(self.x_values, self.y_values, label="Trajectory", color="green")

            # Add orientation arrows
            for x, y, yaw in zip(self.x_values[::10], self.y_values[::10], self.yaw_values[::10]):
                dx = 0.2 * np.cos(yaw)
                dy = 0.2 * np.sin(yaw)
                self.ax.arrow(x, y, dx, dy, head_width=0.1, head_length=0.1, fc='r', ec='r')

            self.ax.set_xlabel("X (meters)")
            self.ax.set_ylabel("Y (meters)")
            self.ax.set_title("Ground Truth Trajectory with Orientation")
            self.ax.legend()
            self.ax.grid(True)

        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

    def run_plot_loop(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.update_plot()
            rate.sleep()

if __name__ == "__main__":
    try:
        Ground_Truth_Plotter()
    except rospy.ROSInterruptException:
        pass

