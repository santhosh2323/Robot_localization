#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Imu
import random
import numpy as np

def publish_imu_data():
    rospy.init_node('imu_publisher', anonymous=True)
    pub = rospy.Publisher('/kitti/oxts/imu', Imu, queue_size=10)
    rate = rospy.Rate(0.2)  # 5 seconds interval (0.2 Hz)

    while not rospy.is_shutdown():
        imu_msg = Imu()
        imu_msg.header.stamp = rospy.Time.now()
        imu_msg.header.frame_id = 'imu_frame'
        imu_msg.orientation.x = random.uniform(-1.0, 1.0)
        imu_msg.orientation.y = random.uniform(-1.0, 1.0)
        imu_msg.orientation.z = random.uniform(-1.0, 1.0)
        imu_msg.orientation.w = random.uniform(-1.0, 1.0)
        norm = np.sqrt(imu_msg.orientation.x**2 + imu_msg.orientation.y**2 + imu_msg.orientation.z**2 + imu_msg.orientation.w**2)
        imu_msg.orientation.x /= norm
        imu_msg.orientation.y /= norm
        imu_msg.orientation.z /= norm
        imu_msg.orientation.w /= norm
        imu_msg.angular_velocity.x = random.uniform(-5.0, 5.0)
        imu_msg.angular_velocity.y = random.uniform(-5.0, 5.0)
        imu_msg.angular_velocity.z = random.uniform(-5.0, 5.0)
        imu_msg.linear_acceleration.x = random.uniform(-10.0, 10.0)
        imu_msg.linear_acceleration.y = random.uniform(-10.0, 10.0)
        imu_msg.linear_acceleration.z = random.uniform(-10.0, 10.0)
        pub.publish(imu_msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        publish_imu_data()
    except rospy.ROSInterruptException:
        pass

