#!/usr/bin/env python3

import rospy
from nav_msgs.msg import Odometry
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point

POS_SCALE = 0.01  # Scaling factor for visualization


class TrajectoryMarkers:
    def __init__(self):
        # Initialize trajectory positions
        self.filtered_pos = []
        self.ground_truth_pos = []
        self.initial_ground_truth_pos = None

        # Create publishers for RViz markers
        self.filtered_trajectory_pub = rospy.Publisher(
            'trajectory_markers/filtered', Marker, queue_size=10)
        self.ground_truth_trajectory_pub = rospy.Publisher(
            'trajectory_markers/ground_truth', Marker, queue_size=10)

        # Subscribers for odometry topics
        rospy.Subscriber("odometry/filtered", Odometry, self.update_filtered_pos)
        rospy.Subscriber("kitti/oxts/odom", Odometry, self.update_ground_truth_pos)

    def update_filtered_pos(self, msg):
        # Append the filtered odometry position
        self.filtered_pos.append(Point(
            msg.pose.pose.position.x * POS_SCALE,
            msg.pose.pose.position.y * POS_SCALE,
            msg.pose.pose.position.z * POS_SCALE
        ))

        # Publish filtered trajectory as a line strip (White)
        self.publish_trajectory(self.filtered_pos, self.filtered_trajectory_pub, [1.0, 0.647, 0.0, 1.0])  # orange

    def update_ground_truth_pos(self, msg):
        # Initialize ground truth starting position for normalization
        if self.initial_ground_truth_pos is None:
            self.initial_ground_truth_pos = msg.pose.pose.position
            return

        # Append normalized ground truth position
        self.ground_truth_pos.append(Point(
            (msg.pose.pose.position.x - self.initial_ground_truth_pos.x) * POS_SCALE,
            (msg.pose.pose.position.y - self.initial_ground_truth_pos.y) * POS_SCALE,
            (msg.pose.pose.position.z - self.initial_ground_truth_pos.z) * POS_SCALE
        ))

        # Publish ground truth trajectory as a line strip (Red)
        self.publish_trajectory(self.ground_truth_pos, self.ground_truth_trajectory_pub, [1.0, 0.0, 0.0, 1.0])  # Red

    def publish_trajectory(self, points, publisher, color):
        # Create a line strip marker
        marker = Marker()
        marker.header.frame_id = "odom"
        marker.header.stamp = rospy.Time.now()
        marker.ns = "trajectory"
        marker.id = 0
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD

        # Add points to the marker
        marker.points = points

        # Set marker properties
        marker.scale.x = 0.05  # Line width
        marker.color.r = color[0]
        marker.color.g = color[1]
        marker.color.b = color[2]
        marker.color.a = color[3]

        # Publish the marker
        publisher.publish(marker)


if __name__ == '__main__':
    rospy.init_node("rviz_plotter", anonymous=True)
    trajectory_markers = TrajectoryMarkers()
    rospy.spin()

